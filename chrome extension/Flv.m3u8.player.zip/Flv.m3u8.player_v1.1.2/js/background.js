// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};

const setupNetworkRules = async () => {
    const staticRules = [
        {
            id: 1,
            priority: 1,
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
                redirect: {
                    regexSubstitution: `${chrome.runtime.getURL("player.html")}#\\0`
                }
            },
            condition: {
                regexFilter: "^.*(?:\\.flv(?:\\?|$)|#flv$)",
                resourceTypes: [ chrome.declarativeNetRequest.ResourceType.MAIN_FRAME ]
            }
        },
        {
            id: 2,
            priority: 2,
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
                redirect: {
                    regexSubstitution: `${chrome.runtime.getURL("player.html")}#\\0`
                }
            },
            condition: {
                regexFilter: "^.*(?:\\.ts(?:\\?|$)|#ts$)",
                resourceTypes: [ chrome.declarativeNetRequest.ResourceType.MAIN_FRAME ]
            }
        },        
        {
            id: 3,
            priority: 3,
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
                redirect: {
                    regexSubstitution: `${chrome.runtime.getURL("player.html")}#\\0`
                }
            },
            condition: {
                regexFilter: "^.*(?:\\.m3u8(?:\\?|$)|#m3u8$)",
                resourceTypes: [ chrome.declarativeNetRequest.ResourceType.MAIN_FRAME ]
            }
        }
    ];

    // 获取当前存储的 headerRules
    const result = await chrome.storage.local.get(['headerRules']);
    const headerRules = result.headerRules || [];
    
    const dynamicRules = headerRules.map((rule, index) => {
        const requestHeaders = Object.entries(rule.headers).map(([header, value]) => ({
            header: header,
            operation: chrome.declarativeNetRequest.HeaderOperation.SET,
            value: String(value)
        }));

        // 将 pattern 转换为 globFilter 格式
        // DNR 的 urlFilter 支持通配符，如果 pattern 已经是 *.example.com 这种，通常可以直接用
        let urlFilter = rule.pattern;
        if (!urlFilter.includes('*') && !urlFilter.startsWith('http')) {
            urlFilter = `*://${urlFilter}/*`;
        }

        return {
            id: 100 + index,
            priority: 10,
            action: {
                type: chrome.declarativeNetRequest.RuleActionType.MODIFY_HEADERS,
                requestHeaders: requestHeaders
            },
            condition: {
                urlFilter: urlFilter,
                resourceTypes: [
                    chrome.declarativeNetRequest.ResourceType.XMLHTTPREQUEST,
                    chrome.declarativeNetRequest.ResourceType.MEDIA,
                    chrome.declarativeNetRequest.ResourceType.OTHER
                ]
            }
        };
    });

    // 获取所有现有的动态规则 ID 以便清除
    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const existingRuleIds = existingRules.map(rule => rule.id);

    await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: existingRuleIds,
        addRules: [...staticRules, ...dynamicRules]
    });
    console.log("Network rules updated with", dynamicRules.length, "custom header rules");
};

chrome.runtime.onInstalled.addListener(() => {
    console.log("Video Stream Player extension installed");
    setupNetworkRules();
});

chrome.runtime.onStartup.addListener(() => {
    console.log("Video Stream Player extension started");
    setupNetworkRules();
});

// 处理消息监听
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log(`收到消息: ${request.action}`, request);
    
    switch (request.action) {
        case "checkRedirect":
            handleCheckRedirect(request, sendResponse);
            return true;
            
        case "testEpgUrl":
            handleTestEpgUrl(request, sendResponse);
            return true;

        case "updateHeaderRules":
            setupNetworkRules().then(() => {
                sendResponse({ success: true });
            }).catch(err => {
                sendResponse({ success: false, error: err.message });
            });
            return true;

        default:
            console.warn(`未知的消息动作: ${request.action}`);
            sendResponse({ success: false, error: `未知动作: ${request.action}` });
            return false;
    }
});

// 处理重定向检查
function handleCheckRedirect(request, sendResponse) {
    console.log("检测URL重定向:", request.url);
    const controller = new AbortController;
    const signal = controller.signal;
    
    // 设置超时
    const timeoutId = setTimeout(() => {
        controller.abort();
        console.error("重定向检测超时");
        sendResponse({
            success: false,
            error: "请求超时"
        });
    }, 10000);
    
    fetch(request.url, {
        method: "get",
        redirect: "follow",
        headers: {
            "Range": "bytes=0-1",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        },
        signal: signal
    }).then(response => {
        clearTimeout(timeoutId);
        console.log("重定向后的URL:", response.url);
        const contentType = response.headers.get("Content-Type");
        console.log("Content-Type:", contentType);
        console.warn("已获取重定向URL和Content-Type，中止请求。");
        controller.abort();
        sendResponse({
            success: true,
            finalUrl: response.url,
            contentType: contentType
        });
    }).catch(error => {
        clearTimeout(timeoutId);
        if (error.name === "AbortError") {
            console.log("Fetch 请求已中止。");
            sendResponse({
                success: false,
                error: "请求被中止"
            });
        } else {
            console.error("重定向检测失败:", error);
            sendResponse({
                success: false,
                error: error.message
            });
        }
    });
}

// 格式化EPG时间字符串
function formatEpgTimeString(timeStr) {
    if (!timeStr || timeStr.length < 14) return '';
    
    const year = timeStr.substring(0, 4);
    const month = timeStr.substring(4, 6);
    const day = timeStr.substring(6, 8);
    const hour = timeStr.substring(8, 10);
    const min = timeStr.substring(10, 12);
    const sec = timeStr.substring(12, 14);
    const tz = timeStr.substring(14).trim() || '+0000';
    
    return `${year}-${month}-${day}T${hour}:${min}:${sec}${tz.replace(' ', '')}`;
}

// 全局变量
let epgTestTimeoutId = null;

// 简单的XML解析器（使用正则表达式）
function parseXmlSimple(xmlText) {
    const result = {
        channels: [],
        programmes: []
    };
    
    try {
        // 提取频道信息
        const channelRegex = /<channel\s+([^>]+)>([\s\S]*?)<\/channel>/g;
        let channelMatch;
        
        while ((channelMatch = channelRegex.exec(xmlText)) !== null) {
            const attrs = channelMatch[1];
            const content = channelMatch[2];
            
            // 提取id属性
            const idMatch = attrs.match(/id="([^"]+)"/);
            const id = idMatch ? idMatch[1] : '';
            
            // 提取显示名称
            const nameMatch = content.match(/<display-name[^>]*>([^<]+)<\/display-name>/);
            const name = nameMatch ? nameMatch[1].trim() : id;
            
            if (id) {
                result.channels.push({ id, name });
            }
        }
        
        // 提取节目信息
        const programmeRegex = /<programme\s+([^>]+)>([\s\S]*?)<\/programme>/g;
        let programmeMatch;
        
        while ((programmeMatch = programmeRegex.exec(xmlText)) !== null) {
            const attrs = programmeMatch[1];
            const content = programmeMatch[2];
            
            // 提取属性
            const channelMatch = attrs.match(/channel="([^"]+)"/);
            const startMatch = attrs.match(/start="([^"]+)"/);
            const stopMatch = attrs.match(/stop="([^"]+)"/);
            
            // 提取标题
            const titleMatch = content.match(/<title[^>]*>([^<]+)<\/title>/);
            const title = titleMatch ? titleMatch[1].trim() : '未知节目';
            
            if (channelMatch && startMatch) {
                const programme = {
                    channel: channelMatch[1],
                    start: startMatch[1],
                    stop: stopMatch ? stopMatch[1] : '',
                    title: title
                };
                result.programmes.push(programme);
            }
        }
        
        return result;
    } catch (error) {
        console.error('简单XML解析失败:', error);
        throw new Error('XML解析失败: ' + error.message);
    }
}

// 检查是否支持gzip解压（Service Worker环境）
function supportsDecompressionStream() {
    try {
        // 在Service Worker中检查DecompressionStream
        if (typeof DecompressionStream === 'undefined') {
            return false;
        }
        new DecompressionStream('gzip');
        return true;
    } catch (e) {
        return false;
    }
}

// gzip解压函数（Service Worker兼容版）
async function decompressGzip(buffer) {
    try {
        // 首先尝试使用DecompressionStream
        if (supportsDecompressionStream()) {
            const decompressedStream = new Response(
                new Blob([buffer]).stream().pipeThrough(
                    new DecompressionStream('gzip')
                )
            );
            return await decompressedStream.text();
        } else {
            // 备选方案：使用纯JavaScript的gzip解压
            // 这里使用一个简单的实现，对于小文件可能有效
            throw new Error('Service Worker环境不支持gzip解压');
        }
    } catch (error) {
        console.error('gzip解压失败:', error);
        throw new Error('无法解压gzip数据: ' + error.message);
    }
}

// EPG测试函数（Service Worker兼容版 - 无DOMParser）
async function testEpgUrl(url) {
    try {
        console.log(`[EPG测试] 开始测试EPG数据源: ${url}`);
        
        // 设置超时
        const timeoutPromise = new Promise((_, reject) => {
            epgTestTimeoutId = setTimeout(() => {
                reject(new Error('EPG数据源测试超时（30秒）'));
            }, 30000);
        });
        
        const fetchPromise = (async () => {
            const response = await fetch(url, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/xml,text/xml,*/*',
                    'Accept-Encoding': 'gzip, deflate'
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            let text;
            const contentType = response.headers.get('content-type') || '';
            const contentLength = response.headers.get('content-length');
            const isGzipped = 
                contentType.includes('gzip') || 
                contentType.includes('application/gzip') ||
                url.toLowerCase().endsWith('.gz');
            
            console.log(`[EPG测试] Content-Type: ${contentType}, Content-Length: ${contentLength}, Gzipped: ${isGzipped}`);
            
            if (isGzipped) {
                console.log('[EPG测试] 检测到gzip压缩，尝试解压...');
                try {
                    const buffer = await response.arrayBuffer();
                    text = await decompressGzip(buffer);
                } catch (decompressError) {
                    // 如果解压失败，返回原始数据（可能浏览器会自动解压）
                    console.warn('[EPG测试] gzip解压失败，尝试作为文本读取:', decompressError.message);
                    text = await response.text();
                }
            } else {
                text = await response.text();
            }
            
            console.log(`[EPG测试] 获取数据成功，大小: ${text.length} 字符`);
            
            // 检查是否是有效的XML
            const trimmedText = text.trim();
            if (!trimmedText.startsWith('<?xml') && !trimmedText.startsWith('<tv')) {
                console.log('[EPG测试] 数据内容前100字符:', text.substring(0, 100));
                // 尝试修复常见的XML格式问题
                if (trimmedText.includes('<tv>') || trimmedText.includes('<programme')) {
                    console.log('[EPG测试] 数据包含有效的XML标签，继续处理');
                } else {
                    throw new Error('数据格式不正确，可能不是有效的XML文件');
                }
            }
            
            // 使用简单的XML解析器
            const parsedData = parseXmlSimple(text);
            
            console.log(`[EPG测试] 解析成功: ${parsedData.channels.length} 个频道, ${parsedData.programmes.length} 个节目`);
            
            if (parsedData.programmes.length === 0) {
                throw new Error('EPG数据中没有找到节目信息');
            }
            
            // 提取一些节目信息作为测试结果
            const testData = [];
            const maxPrograms = Math.min(parsedData.programmes.length, 15);
            
            for (let i = 0; i < maxPrograms; i++) {
                const prog = parsedData.programmes[i];
                
                // 转换时间
                let start = null;
                let stop = null;
                
                if (prog.start) {
                    try {
                        const dateStr = formatEpgTimeString(prog.start);
                        start = Date.parse(dateStr);
                    } catch (e) {
                        console.warn(`[EPG测试] 时间解析失败: ${prog.start}`);
                    }
                }
                
                if (prog.stop) {
                    try {
                        const dateStr = formatEpgTimeString(prog.stop);
                        stop = Date.parse(dateStr);
                    } catch (e) {
                        console.warn(`[EPG测试] 时间解析失败: ${prog.stop}`);
                    }
                }
                
                // 获取频道名称
                let channelName = prog.channel;
                const channelInfo = parsedData.channels.find(ch => ch.id === prog.channel);
                if (channelInfo) {
                    channelName = channelInfo.name;
                }
                
                testData.push({ 
                    start, 
                    stop, 
                    title: prog.title,
                    channel: channelName
                });
            }
            
            return {
                success: true,
                data: testData,
                stats: {
                    channels: parsedData.channels.length,
                    programmes: parsedData.programmes.length,
                    testSamples: maxPrograms
                }
            };
        })();
        
        const result = await Promise.race([fetchPromise, timeoutPromise]);
        
        // 清除超时定时器
        if (epgTestTimeoutId) {
            clearTimeout(epgTestTimeoutId);
            epgTestTimeoutId = null;
        }
        
        return result;
        
    } catch (error) {
        console.error('[EPG测试] 测试失败:', error);
        
        // 清除超时定时器
        if (epgTestTimeoutId) {
            clearTimeout(epgTestTimeoutId);
            epgTestTimeoutId = null;
        }
        
        throw error;
    }
}

// 处理EPG测试
async function handleTestEpgUrl(request, sendResponse) {
    try {
        if (!request.url || typeof request.url !== 'string') {
            throw new Error('无效的URL地址');
        }
        
        // 验证URL格式
        let testUrl = request.url.trim();
        if (!testUrl.startsWith('http://') && !testUrl.startsWith('https://')) {
            testUrl = 'http://' + testUrl;
        }
        
        try {
            new URL(testUrl);
        } catch (e) {
            throw new Error('URL格式不正确');
        }
        
        const result = await testEpgUrl(testUrl);
        sendResponse(result);
        
    } catch (error) {
        console.error('EPG测试处理失败:', error);
        sendResponse({
            success: false,
            error: error.message || 'EPG测试失败'
        });
    }
}