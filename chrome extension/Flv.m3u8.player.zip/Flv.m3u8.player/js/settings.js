// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};

document.addEventListener("DOMContentLoaded", function() {
    // DOM 元素
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    const backBtn = document.querySelector('.back-btn');
    const saveBtn = document.getElementById('saveBtn');
    const resetBtn = document.getElementById('resetBtn');
    const blacklistInput = document.getElementById('blacklistInput');
    const addKeywordBtn = document.getElementById('addKeywordBtn');
    const blacklistItems = document.getElementById('blacklistItems');
    // EPG相关元素
    const showEPGCheckbox = document.getElementById('showEPG');
    const epgUpdateIntervalInput = document.getElementById('epgUpdateInterval');
    const epgUrlInput = document.getElementById('epgUrlInput');
    const addEpgUrlBtn = document.getElementById('addEpgUrlBtn');
    const presetEpgSelect = document.getElementById('presetEpgSelect');
    const addPresetEpgBtn = document.getElementById('addPresetEpgBtn');
    const epgUrlList = document.getElementById('epgUrlList');
    const epgTestResult = document.getElementById('epgTestResult');
    const epgTestResultContent = document.getElementById('epgTestResultContent');
    const epgTestTitle = document.getElementById('epgTestTitle');
    const closeTestResultBtn = document.getElementById('closeTestResultBtn');
    // 全局EPG管理器实例
    let epgManager = null;
    // 默认配置
    const DEFAULT_CONFIG = {
        loadTimeout: 10,            // 秒
        stallTimeout: 10,            // 秒
        maxRetryRounds: 2,          // 轮
        searchDebounce: 300,        // 毫秒
        playlistRefreshInterval: 10, // 分钟
        autoRefreshEnabled: true,
        showEPG: true,              // 是否显示EPG
        epgUpdateInterval: 60,       // 分钟
        epgUrls: [],                // EPG源URL数组
        activeEpgUrl: '',           // 当前活动的EPG源
        blacklist: []               // 黑名单关键词数组
    };
    // 当前配置
    let currentConfig = { ...DEFAULT_CONFIG };
    // 初始化标签页切换
    function initTabs() {
        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.getAttribute('data-tab');
                // 更新标签状态
                tabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                // 更新内容显示
                tabContents.forEach(content => {
                    content.classList.remove('active');
                });
                const targetTab = document.getElementById(`${tabId}-tab`);
                if (targetTab) {
                    targetTab.classList.add('active');
                }
            });
        });
    }
    // 初始化EPG管理器
    function initEPGManager() {
        try {
            if (typeof EPGManager !== 'undefined') {
                epgManager = new EPGManager();
                console.log('[设置] EPG管理器初始化成功');
                // 显示压缩支持信息
                const gzipSupportEl = document.getElementById('gzipSupportContent');
                const gzipSupportResultEl = document.getElementById('gzipSupportResult');
                if (gzipSupportEl && gzipSupportResultEl) {
                    if (epgManager.isGzipSupported) {
                        gzipSupportResultEl.className = 'test-result success';
                        gzipSupportEl.innerHTML = `
                            <strong>✓ 浏览器支持压缩格式</strong><br>
                            <small>您的浏览器支持 .gz 压缩格式，可以正常使用压缩的EPG文件。</small>
                        `;
                    } else {
                        gzipSupportResultEl.className = 'test-result warning';
                        gzipSupportEl.innerHTML = `
                            <strong>⚠️ 浏览器不支持压缩格式</strong><br>
                            <small>您的浏览器不支持 .gz 压缩格式解压，将无法使用压缩的EPG文件。请使用Chrome 80+、Firefox 113+、Edge 80+或Safari 16.4+版本。</small>
                        `;
                    }
                }
            } else {
                console.error('[设置] EPGManager类未定义，请检查js/epgmanager.js是否正确加载');
                showMessage('EPG管理器加载失败，请刷新页面', false);
            }
        } catch (error) {
            console.error('[设置] EPG管理器初始化失败:', error);
        }
    }
    // 加载设置
    function loadSettings() {
        console.log('[设置] 开始加载设置');
        
        // 首先设置默认值到输入框
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        const showEPGInput = document.getElementById('showEPG');
        const epgUpdateIntervalInput = document.getElementById('epgUpdateInterval');
        
        // 检查所有必要的输入元素是否存在
        if (!loadTimeoutInput || !stallTimeoutInput || !maxRetryRoundsInput || 
            !searchDebounceInput || !playlistRefreshIntervalInput || !autoRefreshEnabledInput ||
            !showEPGInput || !epgUpdateIntervalInput) {
            console.error('[设置] 找不到必要的输入元素，页面可能未完全加载');
            // 延迟重试
            setTimeout(loadSettings, 100);
            return;
        }
        
        // 设置默认值到UI
        console.log('[设置] 设置默认值到UI元素');
        loadTimeoutInput.value = DEFAULT_CONFIG.loadTimeout;
        stallTimeoutInput.value = DEFAULT_CONFIG.stallTimeout;
        maxRetryRoundsInput.value = DEFAULT_CONFIG.maxRetryRounds;
        searchDebounceInput.value = DEFAULT_CONFIG.searchDebounce;
        playlistRefreshIntervalInput.value = DEFAULT_CONFIG.playlistRefreshInterval;
        autoRefreshEnabledInput.checked = DEFAULT_CONFIG.autoRefreshEnabled;
        showEPGInput.checked = DEFAULT_CONFIG.showEPG;
        epgUpdateIntervalInput.value = DEFAULT_CONFIG.epgUpdateInterval;
        
        // 设置当前配置的默认值
        currentConfig.loadTimeout = DEFAULT_CONFIG.loadTimeout;
        currentConfig.stallTimeout = DEFAULT_CONFIG.stallTimeout;
        currentConfig.maxRetryRounds = DEFAULT_CONFIG.maxRetryRounds;
        currentConfig.searchDebounce = DEFAULT_CONFIG.searchDebounce;
        currentConfig.playlistRefreshInterval = DEFAULT_CONFIG.playlistRefreshInterval;
        currentConfig.autoRefreshEnabled = DEFAULT_CONFIG.autoRefreshEnabled;
        currentConfig.showEPG = DEFAULT_CONFIG.showEPG;
        currentConfig.epgUpdateInterval = DEFAULT_CONFIG.epgUpdateInterval;
        
        // 然后从存储加载（如果有的话）
        chrome.storage.local.get([
            'loadTimeout',
            'stallTimeout',
            'maxRetryRounds',
            'searchDebounce',
            'playlistRefreshInterval',
            'autoRefreshEnabled',
            'showEPG',
            'epgUpdateInterval',
            'epgUrls',
            'activeEpgUrl',
            'blacklist'
        ], function(result) {
            console.log('[设置] 从存储加载的数据:', result);
            
            // 如果有存储的值，覆盖默认值
            if (loadTimeoutInput && result.loadTimeout !== undefined) {
                loadTimeoutInput.value = Math.round(result.loadTimeout / 1000);
                currentConfig.loadTimeout = Math.round(result.loadTimeout / 1000);
                console.log('[设置] 加载超时:', result.loadTimeout, '->', Math.round(result.loadTimeout / 1000));
            }
            
            if (stallTimeoutInput && result.stallTimeout !== undefined) {
                stallTimeoutInput.value = Math.round(result.stallTimeout / 1000);
                currentConfig.stallTimeout = Math.round(result.stallTimeout / 1000);
                console.log('[设置] 卡顿检测:', result.stallTimeout, '->', Math.round(result.stallTimeout / 1000));
            }
            
            if (maxRetryRoundsInput && result.maxRetryRounds !== undefined) {
                maxRetryRoundsInput.value = result.maxRetryRounds;
                currentConfig.maxRetryRounds = result.maxRetryRounds;
                console.log('[设置] 最大重试轮次:', result.maxRetryRounds);
            }
            
            if (searchDebounceInput && result.searchDebounce !== undefined) {
                searchDebounceInput.value = result.searchDebounce;
                currentConfig.searchDebounce = result.searchDebounce;
                console.log('[设置] 搜索防抖:', result.searchDebounce);
            }
            
            if (playlistRefreshIntervalInput && result.playlistRefreshInterval !== undefined) {
                playlistRefreshIntervalInput.value = Math.round(result.playlistRefreshInterval / 60000);
                currentConfig.playlistRefreshInterval = Math.round(result.playlistRefreshInterval / 60000);
                console.log('[设置] 播放列表刷新间隔:', result.playlistRefreshInterval, '->', Math.round(result.playlistRefreshInterval / 60000));
            }
            
            if (autoRefreshEnabledInput && result.autoRefreshEnabled !== undefined) {
                autoRefreshEnabledInput.checked = result.autoRefreshEnabled;
                currentConfig.autoRefreshEnabled = result.autoRefreshEnabled;
                console.log('[设置] 自动刷新启用:', result.autoRefreshEnabled);
            }
            
            if (showEPGInput && result.showEPG !== undefined) {
                showEPGInput.checked = result.showEPG;
                currentConfig.showEPG = result.showEPG;
                console.log('[设置] 显示EPG:', result.showEPG);
            }
            
            if (epgUpdateIntervalInput && result.epgUpdateInterval !== undefined) {
                epgUpdateIntervalInput.value = Math.round(result.epgUpdateInterval / 60000);
                currentConfig.epgUpdateInterval = Math.round(result.epgUpdateInterval / 60000);
                console.log('[设置] EPG更新间隔:', result.epgUpdateInterval, '->', Math.round(result.pgUpdateInterval / 60000));
            }
            
            // 加载EPG源 - 修复：确保是字符串数组
            if (result.epgUrls && Array.isArray(result.epgUrls)) {
                // 过滤掉非字符串项，确保所有项都是字符串
                currentConfig.epgUrls = result.epgUrls.filter(url => typeof url === 'string');
                currentConfig.activeEpgUrl = typeof result.activeEpgUrl === 'string' ? result.activeEpgUrl : '';
                console.log('[设置] 加载EPG源:', currentConfig.epgUrls.length, '个');
                renderEpgUrls();
            }
            
            // 加载黑名单
            if (result.blacklist && Array.isArray(result.blacklist)) {
                currentConfig.blacklist = result.blacklist;
                console.log('[设置] 加载黑名单:', currentConfig.blacklist.length, '个关键词');
                renderBlacklist();
            } else {
                // 如果 storage 中没有黑名单，尝试从文件加载
                console.log('[设置] 从文件加载黑名单');
                loadBlacklistFromFile();
            }
            
            console.log('[设置] 设置加载完成');
        });
    }
    // 从文件加载黑名单
    function loadBlacklistFromFile() {
        fetch(chrome.runtime.getURL('blacklist.txt'))
            .then(response => response.text())
            .then(text => {
                const keywords = text.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                currentConfig.blacklist = keywords;
                renderBlacklist();
            })
            .catch(error => {
                console.warn('无法加载黑名单文件:', error);
                currentConfig.blacklist = [];
                renderBlacklist();
            });
    }
    // 渲染黑名单列表
    function renderBlacklist() {
        if (!blacklistItems) return;
        blacklistItems.innerHTML = '';
        if (currentConfig.blacklist.length === 0) {
            blacklistItems.innerHTML = `
                <div class="empty-state">
                    <div>📝</div>
                    <p>暂无黑名单规则</p>
                    <p class="tip">添加关键词以过滤不需要的内容</p>
                </div>
            `;
            return;
        }
        currentConfig.blacklist.forEach((keyword, index) => {
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            item.innerHTML = `
                <div class="blacklist-keyword">${escapeHtml(keyword)}</div>
                <div class="blacklist-actions">
                    <button class="edit-btn" data-index="${index}">✏️</button>
                    <button class="delete-btn" data-index="${index}">🗑️</button>
                </div>
            `;
            blacklistItems.appendChild(item);
        });
        // 添加事件监听器
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                editKeyword(index);
            });
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                deleteKeyword(index);
            });
        });
    }
    // 渲染EPG源列表 - 修复类型检查
    function renderEpgUrls() {
        if (!epgUrlList) return;
        epgUrlList.innerHTML = '';
        if (currentConfig.epgUrls.length === 0) {
            epgUrlList.innerHTML = `
                <div class="empty-state">
                    <div>📺</div>
                    <p>暂无EPG源</p>
                    <p class="tip">添加EPG源以显示节目指南</p>
                </div>
            `;
            return;
        }
        currentConfig.epgUrls.forEach((url, index) => {
            // 确保url是字符串
            if (typeof url !== 'string') {
                console.warn(`[设置] 跳过非字符串EPG源:`, url);
                return;
            }
            const isActive = url === currentConfig.activeEpgUrl;
            const displayName = getEpgDisplayName(url);
            const formatType = getEpgFormatType(url);
            const item = document.createElement('div');
            item.className = `epg-url-item ${isActive ? 'active' : ''}`;
            item.innerHTML = `
                <div class="epg-url-info">
                    <div class="epg-url-name">${escapeHtml(displayName)}</div>
                    <div class="epg-url-meta">
                        <span>${escapeHtml(url.length > 60 ? url.substring(0, 57) + '...' : url)}</span>
                        <span style="background: ${getFormatColor(formatType)}; color: white; padding: 1px 4px; border-radius: 3px; font-size: 10px; font-weight: bold;">${formatType}</span>
                    </div>
                </div>
                <div class="epg-url-actions">
                    ${!isActive ? `<button class="activate-btn" data-index="${index}" title="设为默认">✓</button>` : ''}
                    <button class="test-btn" data-url="${escapeHtml(url)}" title="测试连接">🔍</button>
                    <button class="delete-btn" data-index="${index}" title="删除">🗑️</button>
                </div>
            `;
            epgUrlList.appendChild(item);
        });
        // 添加事件监听器
        document.querySelectorAll('.activate-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                activateEpgUrl(index);
            });
        });
        document.querySelectorAll('.test-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const url = e.target.getAttribute('data-url');
                testEpgUrl(url);
            });
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const index = parseInt(e.target.getAttribute('data-index'));
                deleteEpgUrl(index);
            });
        });
    }
    // 获取EPG格式类型 - 修复类型检查
    function getEpgFormatType(url) {
        if (typeof url !== 'string') {
            return '未知';
        }
        const urlLower = url.toLowerCase();
        if (urlLower.endsWith('.gz') || urlLower.endsWith('.gzip')) {
            return '压缩';
        }
        return 'XML';
    }
    // 获取格式颜色
    function getFormatColor(formatType) {
        switch(formatType) {
            case '压缩': return '#3498db';  // 蓝色
            case 'XML': return '#27ae60';   // 绿色
            default: return '#666';         // 灰色
        }
    }
    // 获取EPG源的显示名称 - 修复类型检查
    function getEpgDisplayName(url) {
        if (typeof url !== 'string') {
            return '无效URL';
        }
        try {
            const urlObj = new URL(url);
            let name = urlObj.hostname.replace(/^www\./, '');
            // 为常见EPG源提供友好的名称
            if (name.includes('githubusercontent.com')) {
                return 'GitHub EPG源';
            } else if (name.includes('raw.githubusercontent.com')) {
                return 'GitHub原始文件';
            } else if (name.includes('gh-proxy.org')) {
                return 'GitHub文件已加速';
            } else if (name.includes('epg.112114.xyz')) {
                return '112114 EPG源';
            }
            // 获取路径的最后一部分作为名称
            const pathParts = urlObj.pathname.split('/').filter(part => part);
            if (pathParts.length > 0) {
                const lastPart = pathParts[pathParts.length - 1];
                if (lastPart.includes('.xml') || lastPart.includes('.gz')) {
                    name = lastPart.replace(/\.[^/.]+$/, '') + ' - ' + name;
                }
            }
            return name;
        } catch (e) {
            return url.length > 40 ? url.substring(0, 37) + '...' : url;
        }
    }
    // 添加EPG源
    function addEpgUrl() {
        if (!epgUrlInput) return;
        let url = epgUrlInput.value.trim();
        if (!url) {
            alert('请输入EPG源URL');
            return;
        }
        // 确保URL以http或https开头
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'http://' + url;
        }
        // 验证URL格式
        try {
            new URL(url);
        } catch (e) {
            alert('请输入有效的URL地址');
            return;
        }
        // 检查是否已存在
        if (currentConfig.epgUrls.includes(url)) {
            alert('该EPG源已存在');
            return;
        }
        // 添加到列表
        currentConfig.epgUrls.push(url);
        // 如果是第一个EPG源，设为默认
        if (currentConfig.epgUrls.length === 1) {
            currentConfig.activeEpgUrl = url;
        }
        // 清空输入框
        epgUrlInput.value = '';
        // 重新渲染列表
        renderEpgUrls();
        showMessage('EPG源已添加');
        // 自动测试新添加的EPG源
        setTimeout(() => testEpgUrl(url), 500);
    }
    // 添加预设EPG源
    function addPresetEpgUrl() {
        if (!presetEpgSelect) return;
        const url = presetEpgSelect.value;
        if (!url) {
            alert('请选择一个预设EPG源');
            return;
        }
        // 检查是否已存在
        if (currentConfig.epgUrls.includes(url)) {
            alert('该EPG源已存在');
            return;
        }
        // 添加到列表
        currentConfig.epgUrls.push(url);
        // 如果是第一个EPG源，设为默认
        if (currentConfig.epgUrls.length === 1) {
            currentConfig.activeEpgUrl = url;
        }
        // 重新渲染列表
        renderEpgUrls();
        showMessage('预设EPG源已添加');
        // 自动测试
        setTimeout(() => testEpgUrl(url), 500);
    }
    // 激活EPG源
    function activateEpgUrl(index) {
        if (index < 0 || index >= currentConfig.epgUrls.length) return;
        const url = currentConfig.epgUrls[index];
        if (typeof url !== 'string') return;
        currentConfig.activeEpgUrl = url;
        renderEpgUrls();
        showMessage('EPG源已设为默认');
    }
    // 测试EPG源
    async function testEpgUrl(url) {
        if (!url || typeof url !== 'string') return;
        // 检查EPG管理器是否可用
        if (!epgManager) {
            showMessage('EPG管理器未初始化，请刷新页面', false);
            return;
        }
        // 显示加载状态
        epgTestResult.style.display = 'block';
        epgTestResult.className = 'test-result loading';
        epgTestTitle.textContent = '正在测试EPG源...';
        epgTestResultContent.innerHTML = `
            正在连接并解析EPG数据...<br>
            URL: ${escapeHtml(url.length > 80 ? url.substring(0, 77) + '...' : url)}
        `;
        try {
            // 使用EPG管理器测试
            const result = await epgManager.fetchEPG(url, {
                autoRefresh: false,
                retry: 0  // 测试时不重试
            });
            if (result.success) {
                // 显示成功结果
                epgTestResult.className = 'test-result success';
                epgTestTitle.textContent = '✓ 测试成功';
                // 检查是否为压缩格式
                const isCompressed = url.toLowerCase().endsWith('.gz') || url.toLowerCase().endsWith('.gzip');
                const compressionStatus = isCompressed ? 
                    (epgManager.isGzipSupported ? '支持压缩格式' : '压缩格式但浏览器不支持') : 
                    '未压缩格式';
                let contentHtml = `
                    <strong>EPG源信息：</strong><br>
                    <div class="test-result-stats">
                        <div class="stat-item">
                            <div class="stat-value">${result.channels}</div>
                            <div class="stat-label">频道数量</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">${result.programs}</div>
                            <div class="stat-label">节目数量</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">${isCompressed ? '压缩' : 'XML'}</div>
                            <div class="stat-label">格式类型</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">${epgManager.isGzipSupported ? '支持' : '不支持'}</div>
                            <div class="stat-label">压缩支持</div>
                        </div>
                    </div>
                `;
                // 显示压缩格式相关信息
                if (isCompressed) {
                    if (epgManager.isGzipSupported) {
                        contentHtml += `
                            <div style="margin-top: 10px; padding: 8px; background: rgba(52, 152, 219, 0.1); border-radius: 4px; font-size: 12px;">
                                <strong>压缩格式支持：</strong> ✓ 您的浏览器支持 .gz 压缩格式，可以正常解压和使用此EPG源。
                            </div>
                        `;
                    } else {
                        contentHtml += `
                            <div style="margin-top: 10px; padding: 8px; background: rgba(231, 76, 60, 0.1); border-radius: 4px; font-size: 12px;">
                                <strong>警告：</strong> ⚠️ 此EPG源使用压缩格式，但您的浏览器不支持解压。请使用Chrome 80+、Firefox 113+、Edge 80+或Safari 16.4+版本。
                            </div>
                        `;
                    }
                }
                // 显示统计信息
                if (result.stats) {
                    contentHtml += `
                        <div style="margin-top: 15px;">
                            <strong>频道统计：</strong><br>
                            <ul style="margin: 5px 0; font-size: 12px;">
                                <li>数字频道: ${result.stats.numberChannels || 0}个</li>
                                <li>+号频道: ${result.stats.plusChannels || 0}个</li>
                                <li>中文频道: ${result.stats.chineseChannels || 0}个</li>
                                <li>其他频道: ${result.stats.otherChannels || 0}个</li>
                            </ul>
                        </div>
                    `;
                }
                contentHtml += `
                    <div style="margin-top: 10px; font-size: 12px;">
                        <strong>说明：</strong> 此EPG源可以正常使用，保存设置后即可在播放器中显示节目指南。
                    </div>
                `;
                epgTestResultContent.innerHTML = contentHtml;
            } else {
                // 显示错误信息
                throw new Error(result.error || result.friendlyError || 'EPG加载失败');
            }
        } catch (error) {
            console.error('EPG测试失败:', error);
            epgTestResult.className = 'test-result error';
            epgTestTitle.textContent = '✗ 测试失败';
            let errorMessage = error.message || '未知错误';
            // 提供更友好的错误信息
            if (errorMessage.includes('不支持压缩格式解压') || errorMessage.includes('浏览器不支持')) {
                errorMessage = '浏览器不支持 .gz 文件解压。请使用Chrome 80+、Firefox 113+、Edge 80+或Safari 16.4+版本，或者使用未压缩的EPG文件。';
            } else if (errorMessage.includes('网络') || errorMessage.includes('fetch') || errorMessage.includes('HTTP')) {
                errorMessage = '网络连接失败，请检查URL和网络连接';
            } else if (errorMessage.includes('XML') || errorMessage.includes('解析')) {
                errorMessage = 'EPG数据格式错误，可能不是有效的XMLTV格式';
            } else if (errorMessage.includes('超时')) {
                errorMessage = '连接超时，请检查网络或稍后重试';
            }
            epgTestResultContent.innerHTML = `
                <strong>错误信息：</strong> ${errorMessage}<br><br>
                <strong>可能的原因：</strong><br>
                <ul>
                    <li>EPG源URL不正确</li>
                    <li>服务器无法访问</li>
                    <li>网络连接问题</li>
                    <li>EPG源格式不支持</li>
                    <li>浏览器不支持压缩格式（如果使用.gz文件）</li>
                </ul>
                <strong>建议：</strong<br>
                1. 检查URL是否正确<br>
                2. 如果使用.gz文件，请确认浏览器支持<br>
                3. 尝试其他EPG源
            `;
        }
    }
    // 删除EPG源
    function deleteEpgUrl(index) {
        if (index < 0 || index >= currentConfig.epgUrls.length) return;
        const url = currentConfig.epgUrls[index];
        const isActive = url === currentConfig.activeEpgUrl;
        if (!confirm(`确定要删除EPG源吗？\n${url}`)) {
            return;
        }
        // 删除EPG源
        currentConfig.epgUrls.splice(index, 1);
        // 如果删除的是当前激活的EPG源，重新选择第一个作为激活源
        if (isActive && currentConfig.epgUrls.length > 0) {
            currentConfig.activeEpgUrl = currentConfig.epgUrls[0];
        } else if (currentConfig.epgUrls.length === 0) {
            currentConfig.activeEpgUrl = '';
        }
        renderEpgUrls();
        showMessage('EPG源已删除');
    }
    // 添加关键词
    function addKeyword() {
        if (!blacklistInput) return;
        const keyword = blacklistInput.value.trim();
        if (!keyword) {
            alert('请输入关键词');
            return;
        }
        if (currentConfig.blacklist.includes(keyword)) {
            alert('该关键词已存在');
            return;
        }
        currentConfig.blacklist.push(keyword);
        blacklistInput.value = '';
        renderBlacklist();
        showMessage('关键词已添加');
    }
    // 编辑关键词
    function editKeyword(index) {
        const oldKeyword = currentConfig.blacklist[index];
        const newKeyword = prompt('编辑关键词:', oldKeyword);
        if (newKeyword !== null) {
            const trimmedKeyword = newKeyword.trim();
            if (trimmedKeyword && !currentConfig.blacklist.includes(trimmedKeyword)) {
                currentConfig.blacklist[index] = trimmedKeyword;
                renderBlacklist();
                showMessage('关键词已更新');
            } else if (!trimmedKeyword) {
                alert('关键词不能为空');
            } else {
                alert('该关键词已存在');
            }
        }
    }
    // 删除关键词
    function deleteKeyword(index) {
        if (confirm('确定要删除这个关键词吗？')) {
            currentConfig.blacklist.splice(index, 1);
            renderBlacklist();
            showMessage('关键词已删除');
        }
    }
    // 保存设置
    function saveSettings() {
        // 获取表单值
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        const showEPGInput = document.getElementById('showEPG');
        const epgUpdateIntervalInput = document.getElementById('epgUpdateInterval');
        if (!loadTimeoutInput || !stallTimeoutInput || !maxRetryRoundsInput || 
            !searchDebounceInput || !playlistRefreshIntervalInput || !autoRefreshEnabledInput ||
            !showEPGInput || !epgUpdateIntervalInput) {
            showMessage('表单元素缺失，请刷新页面重试', false);
            return;
        }
        const configToSave = {
            loadTimeout: parseInt(loadTimeoutInput.value) * 1000,
            stallTimeout: parseInt(stallTimeoutInput.value) * 1000,
            maxRetryRounds: parseInt(maxRetryRoundsInput.value),
            searchDebounce: parseInt(searchDebounceInput.value),
            playlistRefreshInterval: parseInt(playlistRefreshIntervalInput.value) * 60000,
            autoRefreshEnabled: autoRefreshEnabledInput.checked,
            showEPG: showEPGInput.checked,
            epgUpdateInterval: parseInt(epgUpdateIntervalInput.value) * 60000,
            epgUrls: [...currentConfig.epgUrls],
            activeEpgUrl: currentConfig.activeEpgUrl,
            blacklist: [...currentConfig.blacklist]
        };
        // 验证输入
        if (isNaN(configToSave.loadTimeout) || configToSave.loadTimeout < 1000) {
            alert('加载超时时间必须大于等于1秒');
            loadTimeoutInput.focus();
            return;
        }
        if (isNaN(configToSave.stallTimeout) || configToSave.stallTimeout < 1000) {
            alert('卡顿检测时间必须大于等于1秒');
            stallTimeoutInput.focus();
            return;
        }
        if (isNaN(configToSave.maxRetryRounds) || configToSave.maxRetryRounds < 1) {
            alert('最大重试轮次必须大于等于1');
            maxRetryRoundsInput.focus();
            return;
        }
        if (isNaN(configToSave.playlistRefreshInterval) || configToSave.playlistRefreshInterval < 300000) {
            alert('播放列表刷新间隔必须大于等于5分钟');
            playlistRefreshIntervalInput.focus();
            return;
        }
        if (isNaN(configToSave.epgUpdateInterval) || configToSave.epgUpdateInterval < 60000) {
            alert('EPG更新间隔必须大于等于1分钟');
            epgUpdateIntervalInput.focus();
            return;
        }
        // 保存到 storage
        chrome.storage.local.set(configToSave, function() {
            showMessage('设置已保存！', true);
            // 通知所有打开的播放器页面
            chrome.runtime.sendMessage({
                action: 'settingsUpdated',
                config: configToSave
            });
        });
    }
    // 恢复默认设置
    function resetSettings() {
        if (!confirm('确定要恢复默认设置吗？这将清除所有自定义设置。')) {
            return;
        }
        // 获取表单元素
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        const showEPGInput = document.getElementById('showEPG');
        const epgUpdateIntervalInput = document.getElementById('epgUpdateInterval');
        // 重置表单值
        if (loadTimeoutInput) loadTimeoutInput.value = DEFAULT_CONFIG.loadTimeout;
        if (stallTimeoutInput) stallTimeoutInput.value = DEFAULT_CONFIG.stallTimeout;
        if (maxRetryRoundsInput) maxRetryRoundsInput.value = DEFAULT_CONFIG.maxRetryRounds;
        if (searchDebounceInput) searchDebounceInput.value = DEFAULT_CONFIG.searchDebounce;
        if (playlistRefreshIntervalInput) playlistRefreshIntervalInput.value = DEFAULT_CONFIG.playlistRefreshInterval;
        if (autoRefreshEnabledInput) autoRefreshEnabledInput.checked = DEFAULT_CONFIG.autoRefreshEnabled;
        if (showEPGInput) showEPGInput.checked = DEFAULT_CONFIG.showEPG;
        if (epgUpdateIntervalInput) epgUpdateIntervalInput.value = DEFAULT_CONFIG.epgUpdateInterval;
        // 重置EPG源和黑名单
        currentConfig.epgUrls = [...DEFAULT_CONFIG.epgUrls];
        currentConfig.activeEpgUrl = DEFAULT_CONFIG.activeEpgUrl;
        currentConfig.blacklist = [...DEFAULT_CONFIG.blacklist];
        renderEpgUrls();
        renderBlacklist();
        // 清除 storage 中的设置
        chrome.storage.local.clear(function() {
            showMessage('已恢复默认设置');
        });
    }
    // 显示消息
    function showMessage(message, isSuccess = false) {
        // 移除现有消息
        const existingMessage = document.querySelector('.message-toast');
        if (existingMessage) {
            existingMessage.remove();
        }
        // 创建新消息
        const messageDiv = document.createElement('div');
        messageDiv.className = `message-toast ${isSuccess ? 'success' : 'info'}`;
        messageDiv.textContent = message;
        messageDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 24px;
            background: ${isSuccess ? '#4CAF50' : '#2196F3'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        document.body.appendChild(messageDiv);
        // 3秒后自动移除
        setTimeout(() => {
            if (messageDiv.parentNode) {
                messageDiv.remove();
            }
        }, 3000);
        // 添加动画样式
        if (!document.querySelector('#message-styles')) {
            const style = document.createElement('style');
            style.id = 'message-styles';
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
    }
    // HTML 转义
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    // 初始化
    function init() {
        console.log('[设置] 初始化开始');
        
        // 确保必要元素存在
        if (tabs.length === 0) {
            console.error('[设置] 未找到标签页元素');
            // 延迟重试
            setTimeout(init, 100);
            return;
        }
        if (tabContents.length === 0) {
            console.error('[设置] 未找到标签内容元素');
            // 延迟重试
            setTimeout(init, 100);
            return;
        }
        
        console.log('[设置] 元素检查完成，开始初始化功能');
        initTabs();
        initEPGManager();
        loadSettings();
        
        // 安全地添加事件监听器
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                window.close();
            });
        }
        if (saveBtn) {
            saveBtn.addEventListener('click', saveSettings);
        }
        if (resetBtn) {
            resetBtn.addEventListener('click', resetSettings);
        }
        if (addKeywordBtn) {
            addKeywordBtn.addEventListener('click', addKeyword);
        }
        if (blacklistInput) {
            blacklistInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    addKeyword();
                }
            });
        }
        // EPG相关事件监听器
        if (addEpgUrlBtn) {
            addEpgUrlBtn.addEventListener('click', addEpgUrl);
        }
        if (epgUrlInput) {
            epgUrlInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    addEpgUrl();
                }
            });
        }
        if (addPresetEpgBtn) {
            addPresetEpgBtn.addEventListener('click', addPresetEpgUrl);
        }
        // 关闭测试结果按钮事件
        if (closeTestResultBtn) {
            closeTestResultBtn.addEventListener('click', function() {
                epgTestResult.style.display = 'none';
            });
        }
        // 监听来自其他页面的消息
        chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
            if (message.action === 'updateBlacklist') {
                currentConfig.blacklist = message.blacklist || [];
                renderBlacklist();
            }
        });
        
        console.log('[设置] 初始化完成');
    }
    // 启动初始化
    init();
});